from modulos.Modulo import contarCaracteres

cadena = "Numero 2002"

totaldeM = contarCaracteres(cadena)

Ma= totaldeM[0]
Mi = totaldeM[1]
Num = totaldeM[2]

print("Mayusculas: {}, Minisculas: {}, Numeros: {}".format(Ma, Mi, Num))