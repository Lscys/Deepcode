from modulos.Modulo import dividirEnteros

num1 = 15
num2 = "a"

respuesta = dividirEnteros(num1, num2)

print(respuesta)