from modulos.Modulo import sumarElementos

lista = [1, 2, 5, 8, 9, "a"]

print(sumarElementos(lista))