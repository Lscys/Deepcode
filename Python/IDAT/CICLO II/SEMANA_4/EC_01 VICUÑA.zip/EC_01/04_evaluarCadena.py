from modulos.Modulo import evaluarCadena

cadena = "Hola mundo tengo algo "

print(evaluarCadena(cadena))