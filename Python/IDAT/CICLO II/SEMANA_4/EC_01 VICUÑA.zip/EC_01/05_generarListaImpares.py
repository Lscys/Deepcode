from modulos.Modulo import generarListaImpares

NumeroDeLista = 4

print(generarListaImpares(NumeroDeLista))